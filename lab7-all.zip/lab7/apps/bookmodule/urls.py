from django.urls import path
from . import views

urlpatterns = [
    path('simple/query/', views.simple_query, name='simple_query'),
    path('complex/query/', views.complex_query, name='complex_query'),
    path('search/', views.search_books, name='search_books'),
    path('html5/links/', views.html_links, name='html_links'),
    path('html5/text/formatting/', views.text_formatting, name='text_formatting'),
    path('html5/listing/', views.nested_listing, name='nested_listing'),
    path('html5/tables/', views.tables_view, name='tables_view'),
]
