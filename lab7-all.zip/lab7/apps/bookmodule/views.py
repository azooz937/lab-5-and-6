from django.shortcuts import render

# Create your views here.
from .models import Book

def simple_query(request):
    mybooks = Book.objects.all()  # Fetch all books
    return render(request, 'bookmodule/bookList.html', {'books': mybooks})


def complex_query(request):
    mybooks = Book.objects.filter(author__isnull=False).filter(title__icontains='and').filter(edition__gte=2).exclude(price__lte=100)[:10]
    if len(mybooks) >= 1:
        return render(request, 'bookmodule/bookList.html', {'books': mybooks})
    else:
        return render(request, 'bookmodule/index.html')


def _getBooksList():
    book1 = {'id': 12344321, 'title': 'Continuous Delivery', 'author': 'J. Humble and D. Farley'}
    book2 = {'id': 5678765, 'title': 'Reversing: Secrets of Reverse Engineering', 'author': 'E. Eilam'}
    book3 = {'id': 43211234, 'title': 'The Hundred-Page Machine Learning Book', 'author': 'Andriy Burkov'}
    return [book1, book2, book3]

def search_books(request):
    books = _getBooksList()  # Get the list of books
    filtered_books = []  # Initialize an empty list for filtered results

    if request.method == "POST":
        keyword = request.POST.get('keyword', '').lower()  # Get the keyword from the form
        isTitle = request.POST.get('option1')  # Checkbox for Title
        isAuthor = request.POST.get('option2')  # Checkbox for Author

        # Filter books based on the form input
        for book in books:
            contained = False
            if isTitle and keyword in book['title'].lower():
                contained = True
            if not contained and isAuthor and keyword in book['author'].lower():
                contained = True

            if contained:
                filtered_books.append(book)

        # Render results in bookList.html
        return render(request, 'bookmodule/bookList.html', {'books': filtered_books})

    # Render the search form initially
    return render(request, 'bookmodule/search_form.html')

def html_links(request):
    return render(request, 'bookmodule/links.html')

def text_formatting(request):
    return render(request, 'bookmodule/formatting.html')

def nested_listing(request):
    return render(request, 'bookmodule/listing.html')

def tables_view(request):
    return render(request, 'bookmodule/tables.html')